//
//  ViewController.swift
//  Testing
//
//  Created by zapbuild on 24/01/19.
//  Copyright © 2019 zapbuild. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var myLabel: UILabel!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func GreenButtonClicked(_ sender: Any) {
        myLabel.text="Green Button is clicked"
        myLabel.textColor = UIColor.green
        print("Green Button is clicked")
        
    }
    
    @IBAction func BlueButtonClicked(_ sender: Any) {
        myLabel.textColor = UIColor.blue
        myLabel.text="Blue Button is clicked"
        
        print("Blue Button is clicked")
    }
}

