//
//  SecondScreen.swift
//  Testing
//
//  Created by zapbuild on 27/01/20.
//  Copyright © 2020 zapbuild. All rights reserved.
//

import UIKit

class SecondScreen: UIViewController {

    @IBOutlet weak var textfield: UITextField!
    var nametext=""
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func Submit(_ sender: Any) {
        let thirdScreen=self.storyboard?.instantiateViewController(withIdentifier: "ThirdScreen") as! ThirdScreen
        
        self.nametext = textfield.text!
        performSegue(withIdentifier: "segue", sender: self)
        
        self.present(thirdScreen, animated: true, completion: nil)
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let vc = segue.destination as! ThirdScreen
        vc.finalName = self.nametext

    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
