//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"
let description = "This is a description of playground"
print("\(str) and \(description)")
